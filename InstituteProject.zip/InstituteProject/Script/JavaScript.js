﻿function myFunction(x) {
    x.classList.toggle("change");
    var y = document.getElementById("behide");

    if (y.className === "view") {
        y.className += "inview";
    }
    else {
        y.className = "view";
    }
    
    
}

